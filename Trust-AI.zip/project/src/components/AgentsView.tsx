import { motion } from 'framer-motion';
import {
  Shield,
  Scale,
  Lock,
  FileCheck,
  Eye,
  GitBranch,
  ArrowRight,
  CheckCircle,
  AlertTriangle,
  Zap,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { AgentType } from '../types';

const agents: {
  id: Exclude<AgentType, 'all'>;
  name: string;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
  textColor: string;
  border: string;
  description: string;
  capabilities: string[];
  keywords: string[];
}[] = [
  {
    id: 'privacy',
    name: 'Privacy Agent',
    icon: Lock,
    color: 'bg-emerald-500',
    textColor: 'text-emerald-500',
    border: 'border-emerald-200 dark:border-emerald-900/50',
    description: 'Detects PII and sensitive information: emails, phones, Aadhaar, PAN, passwords, bank details.',
    capabilities: ['Email detection', 'Phone detection', 'Aadhaar detection', 'PAN detection', 'Password detection', 'Bank info detection'],
    keywords: ['privacy', 'sensitive', 'pii', 'personal'],
  },
  {
    id: 'bias',
    name: 'Bias Detection Agent',
    icon: Scale,
    color: 'bg-blue-500',
    textColor: 'text-blue-500',
    border: 'border-blue-200 dark:border-blue-900/50',
    description: 'Analyzes datasets for fairness, demographic balance, and potential discrimination.',
    capabilities: ['Gender imbalance', 'Age analysis', 'Missing values', 'Class imbalance', 'Representation fairness'],
    keywords: ['bias', 'fairness', 'discrimination', 'imbalance'],
  },
  {
    id: 'security',
    name: 'Security Agent',
    icon: Shield,
    color: 'bg-red-500',
    textColor: 'text-red-500',
    border: 'border-red-200 dark:border-red-900/50',
    description: 'Identifies vulnerabilities, prompt injection attacks, and credential exposures.',
    capabilities: ['Prompt injection', 'API key exposure', 'Token detection', 'Jailbreak detection', 'Credential leaks'],
    keywords: ['security', 'vulnerability', 'injection', 'attack'],
  },
  {
    id: 'compliance',
    name: 'Compliance Agent',
    icon: FileCheck,
    color: 'bg-amber-500',
    textColor: 'text-amber-500',
    border: 'border-amber-200 dark:border-amber-900/50',
    description: 'Checks AI governance compliance against NIST, OECD, EU AI Act, and UNESCO standards.',
    capabilities: ['NIST AI RMF', 'OECD Principles', 'EU AI Act', 'Transparency', 'Accountability', 'Human oversight'],
    keywords: ['compliance', 'governance', 'regulation', 'ethical'],
  },
  {
    id: 'explainability',
    name: 'Explainability Agent',
    icon: Eye,
    color: 'bg-cyan-500',
    textColor: 'text-cyan-500',
    border: 'border-cyan-200 dark:border-cyan-900/50',
    description: 'Provides human-readable explanations for AI decisions and risk assessments.',
    capabilities: ['Decision explanation', 'Score breakdown', 'Risk analysis', 'Transparency reporting'],
    keywords: ['explain', 'why', 'transparency', 'reason'],
  },
];

export function AgentsView() {
  // Each agent reads ONLY its own slot from the map. No cross-agent data leaks.
  const { agentResultsMap, setCurrentView } = useApp();

  return (
    <div className="h-full overflow-y-auto scrollbar-thin">
      <div className="mx-auto max-w-5xl px-6 py-6 space-y-6">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="card p-6 bg-surface-900 dark:bg-white text-white dark:text-surface-900"
        >
          <div className="flex items-start gap-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-white/10 dark:bg-surface-900/10">
              <GitBranch className="h-6 w-6" />
            </div>
            <div className="flex-1">
              <h2 className="text-lg font-semibold">Multi-Agent Controller</h2>
              <p className="mt-1 text-sm text-white/70 dark:text-surface-600">
                Routes prompts to the correct AI agent. Each agent is fully isolated — results never overlap.
              </p>
              <div className="mt-3 flex flex-wrap gap-2">
                {['Intent Detection', 'Agent Routing', 'Result Aggregation', 'Trust Scoring'].map(tag => (
                  <span
                    key={tag}
                    className="rounded-full bg-white/10 dark:bg-surface-900/10 px-3 py-1 text-xs font-medium"
                  >
                    {tag}
                  </span>
                ))}
              </div>
              <motion.button
                onClick={() => setCurrentView('chat')}
                className="mt-4 inline-flex items-center gap-2 rounded-lg bg-white dark:bg-surface-900 px-4 py-2 text-sm font-medium text-surface-900 dark:text-white transition-colors hover:bg-surface-100 dark:hover:bg-surface-800"
                whileHover={{ scale: 1.01 }}
                whileTap={{ scale: 0.99 }}
              >
                <Zap className="h-4 w-4" />
                Run Complete Audit
                <ArrowRight className="h-4 w-4" />
              </motion.button>
            </div>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {agents.map((agent, index) => {
            const Icon = agent.icon;
            // ONLY read this agent's own result — other agents' slots are invisible here.
            const result = agentResultsMap[agent.id];
            const hasResult = !!result;

            return (
              <motion.div
                key={agent.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className={`card card-hover p-5 ${agent.border}`}
              >
                <div className="flex items-start gap-3">
                  <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${agent.color}`}>
                    <Icon className="h-5 w-5 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-surface-900 dark:text-surface-100">
                      {agent.name}
                    </h3>
                    <p className="mt-1 text-sm text-surface-500 dark:text-surface-400">
                      {agent.description}
                    </p>

                    {/* Score bar — only shows when THIS agent has been run */}
                    {hasResult && (
                      <div className="mt-3">
                        <div className="flex items-center justify-between mb-1.5">
                          <span className="text-xs font-medium text-surface-600 dark:text-surface-400">
                            Score
                          </span>
                          <span className={`text-sm font-bold ${
                            result.score >= 80 ? 'text-emerald-500' :
                            result.score >= 50 ? 'text-amber-500' : 'text-red-500'
                          }`}>
                            {Math.round(result.score)}%
                          </span>
                        </div>
                        <div className="h-2.5 w-full rounded-full bg-surface-200 dark:bg-surface-700 overflow-hidden">
                          <motion.div
                            initial={{ width: 0 }}
                            animate={{ width: `${result.score}%` }}
                            transition={{ duration: 0.8, ease: 'easeOut' }}
                            className={`h-full rounded-full ${
                              result.score >= 80 ? 'bg-gradient-to-r from-emerald-400 to-emerald-500' :
                              result.score >= 50 ? 'bg-gradient-to-r from-amber-400 to-amber-500' :
                              'bg-gradient-to-r from-red-400 to-red-500'
                            }`}
                          />
                        </div>
                        <p className={`mt-1.5 text-xs font-medium ${
                          result.risk === 'Safe' ? 'text-emerald-600 dark:text-emerald-400' :
                          result.risk === 'Medium Risk' ? 'text-amber-600 dark:text-amber-400' :
                          'text-red-600 dark:text-red-400'
                        }`}>
                          {result.risk}
                        </p>
                      </div>
                    )}
                  </div>
                </div>

                <div className="mt-4 flex flex-wrap gap-1.5">
                  {agent.capabilities.map(cap => (
                    <span
                      key={cap}
                      className={`inline-flex items-center gap-1 text-xs font-medium ${agent.textColor}`}
                    >
                      <CheckCircle className="h-3 w-3" />
                      {cap}
                    </span>
                  ))}
                </div>

                <div className="mt-3 flex flex-wrap gap-1.5">
                  {agent.keywords.map(kw => (
                    <span
                      key={kw}
                      className="rounded bg-surface-100 dark:bg-surface-800 px-2 py-0.5 text-xs text-surface-500 dark:text-surface-400"
                    >
                      {kw}
                    </span>
                  ))}
                </div>

                {/* Findings — only THIS agent's own findings, never another agent's */}
                {hasResult && result.findings.length > 0 && (
                  <div className="mt-4 rounded-lg bg-surface-50 dark:bg-surface-800 p-3 space-y-1.5">
                    {result.findings.slice(0, 3).map((f, i) => (
                      <div key={i} className="flex items-start gap-2 text-xs text-surface-600 dark:text-surface-400">
                        <AlertTriangle className="h-3 w-3 mt-0.5 flex-shrink-0 text-warning-500" />
                        {f}
                      </div>
                    ))}

                    {/* Privacy-only: shareability status */}
                    {agent.id === 'privacy' && result.shareability && (
                      <div className={`mt-2 flex items-center gap-1.5 text-xs font-semibold ${
                        result.shareability === 'NOT SHAREABLE'
                          ? 'text-red-600 dark:text-red-400'
                          : result.shareability === 'SHARE WITH CAUTION'
                            ? 'text-amber-600 dark:text-amber-400'
                            : 'text-emerald-600 dark:text-emerald-400'
                      }`}>
                        <AlertTriangle className="h-3 w-3" />
                        {result.shareability}
                      </div>
                    )}
                  </div>
                )}

                {/* "No data yet" state — shown when this agent hasn't been run */}
                {!hasResult && (
                  <div className="mt-4 rounded-lg border border-dashed border-surface-300 dark:border-surface-700 p-3 text-center">
                    <p className="text-xs text-surface-400 dark:text-surface-500">
                      No results yet. Chat with this agent to see findings here.
                    </p>
                  </div>
                )}

                <motion.button
                  onClick={() => setCurrentView('chat')}
                  className="mt-4 w-full inline-flex items-center justify-center gap-2 rounded-lg bg-surface-100 dark:bg-surface-800 px-3 py-2 text-sm font-medium text-surface-700 dark:text-surface-300 transition-colors hover:bg-surface-200 dark:hover:bg-surface-700"
                  whileHover={{ scale: 1.005 }}
                  whileTap={{ scale: 0.995 }}
                >
                  Analyze
                  <ArrowRight className="h-3.5 w-3.5" />
                </motion.button>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
