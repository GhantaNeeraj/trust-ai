import { motion } from 'framer-motion';
import { User, Shield, Scale, Lock, FileCheck, Eye, GitBranch, AlertTriangle, CheckCircle } from 'lucide-react';
import { ChatMessage as ChatMessageType } from '../types';

interface ChatMessageProps {
  message: ChatMessageType;
  isLast?: boolean;
}

const agentConfig: Record<string, { icon: React.ElementType; color: string }> = {
  Privacy: { icon: Lock, color: 'bg-emerald-500' },
  'Bias Detection': { icon: Scale, color: 'bg-blue-500' },
  Security: { icon: Shield, color: 'bg-red-500' },
  Compliance: { icon: FileCheck, color: 'bg-amber-500' },
  Explainability: { icon: Eye, color: 'bg-cyan-500' },
};

export function ChatMessage({ message, isLast }: ChatMessageProps) {
  const isUser = message.role === 'user';

  const renderContent = (content: string) => {
    const lines = content.split('\n');
    return lines.map((line, index) => {
      if (line.startsWith('## ')) {
        return (
          <h2 key={index} className="mt-4 mb-2 text-base font-semibold text-surface-900 dark:text-surface-100">
            {line.replace('## ', '')}
          </h2>
        );
      }
      if (line.startsWith('### ')) {
        return (
          <h3 key={index} className="mt-3 mb-1.5 text-sm font-semibold text-surface-800 dark:text-surface-200">
            {line.replace('### ', '')}
          </h3>
        );
      }
      if (line.startsWith('**') && line.endsWith('**')) {
        return (
          <p key={index} className="font-semibold text-surface-800 dark:text-surface-200">
            {line.replace(/\*\*/g, '')}
          </p>
        );
      }
      if (line.startsWith('- ')) {
        return (
          <div key={index} className="ml-1 flex items-start gap-2 my-1">
            <span className="text-surface-400 dark:text-surface-500 mt-0.5">-</span>
            <span className="text-surface-700 dark:text-surface-300">
              {renderInlineFormatting(line.replace('- ', ''))}
            </span>
          </div>
        );
      }
      if (line.trim() === '') {
        return <div key={index} className="h-1.5" />;
      }
      return (
        <p key={index} className="my-0.5 text-surface-700 dark:text-surface-300">
          {renderInlineFormatting(line)}
        </p>
      );
    });
  };

  const renderInlineFormatting = (text: string) => {
    const parts = text.split(/(\*\*[^*]+\*\*)/g);
    return parts.map((part, i) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return (
          <strong key={i} className="font-semibold text-surface-900 dark:text-surface-100">
            {part.replace(/\*\*/g, '')}
          </strong>
        );
      }
      return part;
    });
  };

  return (
    <motion.div
      className={`flex gap-3 ${isUser ? 'flex-row-reverse' : 'flex-row'} mb-4`}
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2 }}
    >
      <div
        className={`flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-lg ${
          isUser
            ? 'bg-surface-900 dark:bg-white'
            : 'bg-surface-200 dark:bg-surface-700'
        }`}
      >
        {isUser ? (
          <User className="h-4 w-4 text-white dark:text-surface-900" />
        ) : (
          <GitBranch className="h-4 w-4 text-surface-600 dark:text-surface-300" />
        )}
      </div>

      <div className={`flex max-w-[85%] flex-col gap-2 ${isUser ? 'items-end' : 'items-start'}`}>
        <div className={isUser ? 'message-user' : 'message-assistant'}>
          {renderContent(message.content)}
        </div>

        {/* Single-agent response: show ONLY that one agent's card */}
        {message.singleAgent && message.agentResults && message.agentResults.length === 1 && (
          <motion.div
            className="w-full mt-2"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15 }}
          >
            {message.agentResults.map((result) => {
              const config = agentConfig[result.agent] || { icon: Shield, color: 'bg-surface-500' };
              const Icon = config.icon;
              return (
                <div key={result.agent} className="rounded-lg border border-surface-200 bg-surface-50 p-4 dark:border-surface-700 dark:bg-surface-800">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <div className={`flex h-8 w-8 items-center justify-center rounded-lg ${config.color}`}>
                        <Icon className="h-4 w-4 text-white" />
                      </div>
                      <span className="text-sm font-semibold text-surface-800 dark:text-surface-200">
                        {result.agent} Score
                      </span>
                    </div>
                    <span className={`text-lg font-bold ${result.score >= 80 ? 'text-emerald-600 dark:text-emerald-400' : result.score >= 50 ? 'text-amber-600 dark:text-amber-400' : 'text-red-600 dark:text-red-400'}`}>
                      {result.score}%
                    </span>
                  </div>

                  <div className="h-3 w-full rounded-full bg-surface-200 dark:bg-surface-700 overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${result.score}%` }}
                      transition={{ duration: 0.8, ease: 'easeOut' }}
                      className={`h-full rounded-full ${result.score >= 80 ? 'bg-gradient-to-r from-emerald-400 to-emerald-500' : result.score >= 50 ? 'bg-gradient-to-r from-amber-400 to-amber-500' : 'bg-gradient-to-r from-red-400 to-red-500'}`}
                    />
                  </div>

                  {result.findings.length > 0 && (
                    <div className="mt-3 space-y-1">
                      {result.findings.slice(0, 5).map((finding, i) => (
                        <p key={i} className="text-xs text-surface-600 dark:text-surface-400">{finding}</p>
                      ))}
                    </div>
                  )}

                  {result.agent === 'Privacy' && result.shareability && (
                    <div className="mt-3 space-y-2">
                      <div className="flex items-center gap-2 rounded-lg bg-surface-100 px-3 py-2 dark:bg-surface-700">
                        <span className="text-xs font-medium text-surface-500 dark:text-surface-400">Shareability:</span>
                        <span className={`text-xs font-bold ${result.shareability === 'NOT SHAREABLE' ? 'text-red-600 dark:text-red-400' : result.shareability === 'SHARE WITH CAUTION' ? 'text-amber-600 dark:text-amber-400' : 'text-emerald-600 dark:text-emerald-400'}`}>
                          {result.shareability}
                        </span>
                      </div>
                      {result.sensitiveDataDetected && result.sensitiveDataDetected.length > 0 && (
                        <div className="flex flex-wrap gap-1.5">
                          {result.sensitiveDataDetected.map((d, i) => (
                            <span key={i} className="rounded bg-red-100 px-2 py-0.5 text-xs font-medium text-red-700 dark:bg-red-900/30 dark:text-red-400">{d}</span>
                          ))}
                        </div>
                      )}
                    </div>
                  )}

                  {result.recommendations.length > 0 && (
                    <div className="mt-3 space-y-1.5 border-t border-surface-200 pt-3 dark:border-surface-700">
                      <p className="text-xs font-semibold text-surface-500 dark:text-surface-400">Recommendations</p>
                      {result.recommendations.slice(0, 4).map((rec, i) => (
                        <p key={i} className="flex items-start gap-1.5 text-xs text-surface-600 dark:text-surface-400">
                          <CheckCircle className="h-3 w-3 mt-0.5 text-success-500 flex-shrink-0" />
                          {rec}
                        </p>
                      ))}
                    </div>
                  )}

                  {result.agent === 'Privacy' && result.score < 100 && (
                    <div className="mt-3 flex items-center gap-2 rounded-lg bg-red-50 dark:bg-red-900/20 px-3 py-2">
                      <AlertTriangle className="h-4 w-4 text-red-500 flex-shrink-0" />
                      <p className="text-xs font-medium text-red-700 dark:text-red-400">
                        Do not share this sensitive information with anyone.
                      </p>
                    </div>
                  )}
                </div>
              );
            })}
          </motion.div>
        )}

        {/* Full audit response: show all agent cards + combined Trust Score breakdown */}
        {!message.singleAgent && message.agentResults && message.agentResults.length > 1 && (
          <motion.div
            className="w-full mt-2 space-y-3"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15 }}
          >
            {message.agentResults.map((result) => {
              const config = agentConfig[result.agent] || { icon: Shield, color: 'bg-surface-500' };
              const Icon = config.icon;
              return (
                <div key={result.agent} className="rounded-lg border border-surface-200 bg-surface-50 p-4 dark:border-surface-700 dark:bg-surface-800">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className={`flex h-7 w-7 items-center justify-center rounded-lg ${config.color}`}>
                        <Icon className="h-3.5 w-3.5 text-white" />
                      </div>
                      <span className="text-sm font-semibold text-surface-800 dark:text-surface-200">{result.agent}</span>
                    </div>
                    <span className={`text-sm font-bold ${result.score >= 80 ? 'text-emerald-600 dark:text-emerald-400' : result.score >= 50 ? 'text-amber-600 dark:text-amber-400' : 'text-red-600 dark:text-red-400'}`}>
                      {result.score}%
                    </span>
                  </div>
                  <div className="h-2 w-full rounded-full bg-surface-200 dark:bg-surface-700 overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${result.score}%` }}
                      transition={{ duration: 0.8, ease: 'easeOut' }}
                      className={`h-full rounded-full ${result.score >= 80 ? 'bg-gradient-to-r from-emerald-400 to-emerald-500' : result.score >= 50 ? 'bg-gradient-to-r from-amber-400 to-amber-500' : 'bg-gradient-to-r from-red-400 to-red-500'}`}
                    />
                  </div>
                  {result.agent === 'Privacy' && result.shareability && (
                    <p className={`mt-1.5 text-xs font-semibold ${result.shareability === 'NOT SHAREABLE' ? 'text-red-600 dark:text-red-400' : result.shareability === 'SHARE WITH CAUTION' ? 'text-amber-600 dark:text-amber-400' : 'text-emerald-600 dark:text-emerald-400'}`}>
                      {result.shareability}
                    </p>
                  )}
                </div>
              );
            })}

            {message.trustScore && (
              <div className="rounded-lg border border-surface-200 bg-surface-900 p-4 dark:border-surface-700 dark:bg-white">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-surface-400 dark:text-surface-500">Trust Score</p>
                    <div className="flex items-baseline gap-1">
                      <span className="text-2xl font-bold text-white dark:text-surface-900">{message.trustScore.overall}</span>
                      <span className="text-sm text-surface-400">/100</span>
                    </div>
                  </div>
                  <span className={`text-2xl font-bold ${message.trustScore.overall >= 80 ? 'text-emerald-400 dark:text-emerald-600' : message.trustScore.overall >= 50 ? 'text-amber-400 dark:text-amber-600' : 'text-red-400 dark:text-red-600'}`}>
                    {message.trustScore.grade}
                  </span>
                </div>
              </div>
            )}
          </motion.div>
        )}

        <p className="text-xs text-surface-400 dark:text-surface-500">
          {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </p>
      </div>
    </motion.div>
  );
}
