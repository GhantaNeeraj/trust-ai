import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Download,
  FileText,
  Calendar,
  Filter,
  Eye,
  Trash2,
  CheckCircle,
  AlertTriangle,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

interface Report {
  id: string;
  name: string;
  date: string;
  type: 'full' | 'privacy' | 'security' | 'compliance';
  score: number;
  grade: string;
  findings: number;
}

const mockReports: Report[] = [
  { id: '1', name: 'Customer Dataset Audit', date: 'Jun 17', type: 'full', score: 78, grade: 'B+', findings: 5 },
  { id: '2', name: 'API Prompts Security', date: 'Jun 16', type: 'security', score: 65, grade: 'C+', findings: 12 },
  { id: '3', name: 'User Data Privacy', date: 'Jun 15', type: 'privacy', score: 82, grade: 'A-', findings: 3 },
  { id: '4', name: 'AI Model Compliance', date: 'Jun 14', type: 'compliance', score: 71, grade: 'B', findings: 8 },
];

const typeFilters = [
  { id: 'all', name: 'All' },
  { id: 'full', name: 'Full Audit' },
  { id: 'privacy', name: 'Privacy' },
  { id: 'security', name: 'Security' },
  { id: 'compliance', name: 'Compliance' },
];

export function ReportsView() {
  const [activeFilter, setActiveFilter] = useState('all');
  const [selectedReport, setSelectedReport] = useState<Report | null>(null);
  const { trustScore } = useApp();

  const filteredReports =
    activeFilter === 'all'
      ? mockReports
      : mockReports.filter((r) => r.type === activeFilter);

  const getTypeStyle = (type: string) => {
    switch (type) {
      case 'full':
        return 'bg-surface-900 text-white dark:bg-white dark:text-surface-900';
      case 'privacy':
        return 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400';
      case 'security':
        return 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400';
      case 'compliance':
        return 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400';
      default:
        return 'bg-surface-100 text-surface-700 dark:bg-surface-700 dark:text-surface-300';
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-success-500';
    if (score >= 50) return 'text-warning-500';
    return 'text-danger-500';
  };

  return (
    <div className="h-full overflow-y-auto scrollbar-thin">
      <div className="mx-auto max-w-4xl px-6 py-6 space-y-5">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between"
        >
          <div>
            <h1 className="text-xl font-semibold text-surface-900 dark:text-surface-100">
              Audit Reports
            </h1>
            <p className="mt-0.5 text-sm text-surface-500">View and download reports</p>
          </div>
          <div className="flex items-center gap-2">
            <button className="btn btn-secondary text-sm">
              <Calendar className="h-4 w-4" />
              Last 30 Days
            </button>
            <button className="btn btn-primary text-sm">
              <Download className="h-4 w-4" />
              Export All
            </button>
          </div>
        </motion.div>

        {trustScore && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.05 }}
            className="card p-4"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-surface-900 dark:bg-white">
                  <FileText className="h-4 w-4 text-white dark:text-surface-900" />
                </div>
                <div>
                  <p className="text-sm font-medium text-surface-900 dark:text-surface-100">
                    Current Analysis
                  </p>
                  <p className="text-xs text-surface-500">
                    Score: <span className={getScoreColor(trustScore.overall)}>{trustScore.overall}</span>
                    <span className="mx-1">-</span>
                    Grade: {trustScore.grade}
                  </p>
                </div>
              </div>
              <button className="btn btn-primary text-sm">
                <Download className="h-4 w-4" />
                PDF
              </button>
            </div>
          </motion.div>
        )}

        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="flex items-center gap-2 overflow-x-auto pb-1"
        >
          <Filter className="h-4 w-4 text-surface-400" />
          {typeFilters.map((f) => (
            <button
              key={f.id}
              onClick={() => setActiveFilter(f.id)}
              className={`whitespace-nowrap rounded-lg px-3 py-1.5 text-sm font-medium transition-colors ${
                activeFilter === f.id
                  ? 'bg-surface-900 text-white dark:bg-white dark:text-surface-900'
                  : 'bg-surface-100 text-surface-600 hover:bg-surface-200 dark:bg-surface-800 dark:text-surface-400 dark:hover:bg-surface-700'
              }`}
            >
              {f.name}
            </button>
          ))}
        </motion.div>

        <div className="space-y-2">
          <AnimatePresence mode="popLayout">
            {filteredReports.map((report, index) => (
              <motion.div
                key={report.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, x: -10 }}
                transition={{ delay: index * 0.03 }}
                className="card card-hover group p-3"
              >
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-surface-100 dark:bg-surface-800">
                    <FileText className="h-5 w-5 text-surface-500" />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm font-medium text-surface-900 dark:text-surface-100 truncate">
                        {report.name}
                      </h3>
                      <span className={`rounded px-1.5 py-0.5 text-xs font-medium ${getTypeStyle(report.type)}`}>
                        {report.type.charAt(0).toUpperCase() + report.type.slice(1)}
                      </span>
                    </div>
                    <div className="mt-0.5 flex items-center gap-3 text-xs text-surface-500">
                      <span>{report.date}</span>
                      <span>{report.findings} findings</span>
                    </div>
                  </div>

                  <div className="text-right">
                    <p className={`text-xl font-bold ${getScoreColor(report.score)}`}>
                      {report.score}
                    </p>
                    <p className="text-xs text-surface-400">Grade: {report.grade}</p>
                  </div>

                  <div className="flex items-center gap-1 opacity-0 transition-opacity group-hover:opacity-100">
                    <button
                      onClick={() => setSelectedReport(report)}
                      className="flex h-8 w-8 items-center justify-center rounded-lg text-surface-400 hover:bg-surface-100 hover:text-surface-600 dark:hover:bg-surface-700"
                    >
                      <Eye className="h-4 w-4" />
                    </button>
                    <button className="flex h-8 w-8 items-center justify-center rounded-lg text-surface-400 hover:bg-surface-100 hover:text-surface-600 dark:hover:bg-surface-700">
                      <Download className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        <AnimatePresence>
          {selectedReport && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4"
              onClick={() => setSelectedReport(null)}
            >
              <motion.div
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.95, opacity: 0 }}
                className="w-full max-w-md rounded-xl bg-white p-5 dark:bg-surface-800"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="flex items-start justify-between">
                  <div>
                    <h2 className="text-lg font-semibold text-surface-900 dark:text-surface-100">
                      {selectedReport.name}
                    </h2>
                    <p className="text-sm text-surface-500">{selectedReport.date}</p>
                  </div>
                  <button
                    onClick={() => setSelectedReport(null)}
                    className="text-surface-400 hover:text-surface-600"
                  >
                    <Trash2 className="h-5 w-5" />
                  </button>
                </div>

                <div className="mt-4 grid grid-cols-2 gap-3">
                  <div className="rounded-lg bg-surface-50 p-3 dark:bg-surface-700">
                    <p className="text-xs text-surface-500">Trust Score</p>
                    <p className={`text-2xl font-bold ${getScoreColor(selectedReport.score)}`}>
                      {selectedReport.score}
                    </p>
                  </div>
                  <div className="rounded-lg bg-surface-50 p-3 dark:bg-surface-700">
                    <p className="text-xs text-surface-500">Grade</p>
                    <p className="text-2xl font-bold text-surface-900 dark:text-surface-100">
                      {selectedReport.grade}
                    </p>
                  </div>
                </div>

                <div className="mt-4 flex justify-end gap-2">
                  <button
                    onClick={() => setSelectedReport(null)}
                    className="btn btn-secondary text-sm"
                  >
                    Close
                  </button>
                  <button className="btn btn-primary text-sm">
                    <Download className="h-4 w-4" />
                    Download PDF
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
