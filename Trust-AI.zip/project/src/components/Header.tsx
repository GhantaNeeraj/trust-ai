import { motion } from 'framer-motion';
import { Shield, Sun, Moon, Menu } from 'lucide-react';
import { useApp } from '../context/AppContext';

export function Header() {
  const { isDarkMode, toggleDarkMode } = useApp();

  return (
    <header className="sticky top-0 z-50 border-b border-surface-200 bg-white/90 backdrop-blur-md transition-colors dark:border-surface-800 dark:bg-surface-900/90">
      <div className="flex h-14 items-center justify-between px-4 lg:px-6">
        <motion.div
          className="flex items-center gap-3"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.2 }}
        >
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-surface-900 dark:bg-white">
            <Shield className="h-5 w-5 text-white dark:text-surface-900" />
          </div>
          <div>
            <h1 className="text-lg font-semibold tracking-tight text-surface-900 dark:text-white">
              Trust AI
            </h1>
          </div>
        </motion.div>

        <motion.div
          className="flex items-center gap-1"
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.2 }}
        >
          <button
            onClick={toggleDarkMode}
            className="flex h-9 w-9 items-center justify-center rounded-lg text-surface-500 transition-colors hover:bg-surface-100 hover:text-surface-700 dark:text-surface-400 dark:hover:bg-surface-800 dark:hover:text-surface-200"
            aria-label="Toggle theme"
          >
            <motion.div
              initial={false}
              animate={{ rotate: isDarkMode ? 180 : 0, scale: 1 }}
              transition={{ duration: 0.2 }}
            >
              {isDarkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </motion.div>
          </button>

          <div className="mx-1 h-5 w-px bg-surface-200 dark:bg-surface-700" />

          <div className="flex items-center gap-2 rounded-lg px-2 py-1.5 transition-colors hover:bg-surface-100 dark:hover:bg-surface-800">
            <div className="flex h-7 w-7 items-center justify-center rounded-full bg-surface-900 dark:bg-white">
              <span className="text-xs font-semibold text-white dark:text-surface-900">U</span>
            </div>
          </div>
        </motion.div>
      </div>
    </header>
  );
}
