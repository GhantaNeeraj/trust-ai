import { motion } from 'framer-motion';
import {
  MessageSquare,
  LayoutDashboard,
  Shield,
  Scale,
  Lock,
  FileCheck,
  Eye,
  GitBranch,
  FileText,
  Settings,
  Plus,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

const agents = [
  { id: 'privacy', name: 'Privacy', icon: Lock, color: 'text-emerald-500' },
  { id: 'bias', name: 'Bias', icon: Scale, color: 'text-blue-500' },
  { id: 'security', name: 'Security', icon: Shield, color: 'text-red-500' },
  { id: 'compliance', name: 'Compliance', icon: FileCheck, color: 'text-amber-500' },
  { id: 'explainability', name: 'Explainability', icon: Eye, color: 'text-cyan-500' },
];

export function Sidebar() {
  const { currentView, setCurrentView, trustScore } = useApp();

  const mainNav = [
    { id: 'chat', name: 'Chat', icon: MessageSquare },
    { id: 'dashboard', name: 'Dashboard', icon: LayoutDashboard },
    { id: 'agents', name: 'Agents', icon: GitBranch },
    { id: 'reports', name: 'Reports', icon: FileText },
    { id: 'settings', name: 'Settings', icon: Settings },
  ];

  return (
    <aside className="flex h-full w-60 flex-col border-r border-surface-200 bg-surface-50 transition-colors dark:border-surface-800 dark:bg-surface-900">
      <div className="border-b border-surface-200 p-3 dark:border-surface-800">
        <button
          onClick={() => setCurrentView('chat')}
          className="btn btn-primary w-full gap-2"
        >
          <Plus className="h-4 w-4" />
          New Analysis
        </button>
      </div>

      <div className="flex-1 space-y-6 overflow-y-auto p-3 scrollbar-thin">
        <div>
          <nav className="space-y-0.5">
            {mainNav.map((item, index) => {
              const Icon = item.icon;
              const isActive = currentView === item.id;

              return (
                <motion.button
                  key={item.id}
                  onClick={() => setCurrentView(item.id as 'chat' | 'dashboard' | 'agents' | 'settings' | 'reports')}
                  className={`nav-item w-full ${isActive ? 'nav-item-active' : ''}`}
                  initial={{ opacity: 0, y: 4 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.15, delay: index * 0.03 }}
                >
                  <Icon className="h-4 w-4" />
                  <span>{item.name}</span>
                </motion.button>
              );
            })}
          </nav>
        </div>

        <div>
          <h3 className="mb-2 px-3 text-xs font-semibold uppercase tracking-wider text-surface-400">
            AI Agents
          </h3>
          <nav className="space-y-0.5">
            {agents.map((agent, index) => {
              const Icon = agent.icon;
              return (
                <motion.button
                  key={agent.id}
                  onClick={() => setCurrentView('agents')}
                  className="nav-item w-full"
                  initial={{ opacity: 0, y: 4 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.15, delay: 0.15 + index * 0.03 }}
                >
                  <Icon className={`h-4 w-4 ${agent.color}`} />
                  <span>{agent.name} Agent</span>
                </motion.button>
              );
            })}
          </nav>
        </div>
      </div>

      {trustScore && (
        <motion.div
          className="border-t border-surface-200 p-3 dark:border-surface-800"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.2 }}
        >
          <div className="rounded-lg bg-surface-900 p-3 dark:bg-white dark:text-surface-900">
            <div className="flex items-center justify-between">
              <p className="text-xs font-medium text-surface-400 dark:text-surface-600">
                Trust Score
              </p>
              <span className={`trust-badge ${
                trustScore.overall >= 80 ? 'trust-safe' :
                trustScore.overall >= 50 ? 'trust-medium' : 'trust-high'
              }`}>
                {trustScore.grade}
              </span>
            </div>
            <p className="mt-1 text-2xl font-bold text-white dark:text-surface-900">
              {trustScore.overall}
              <span className="text-sm font-normal text-surface-400 dark:text-surface-500">
                /100
              </span>
            </p>
          </div>
        </motion.div>
      )}
    </aside>
  );
}
