import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Loader2, Sparkles, Paperclip, ChevronDown } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { ChatMessage } from './ChatMessage';
import { FileUpload } from './FileUpload';

const suggestedPrompts = [
  { text: 'Check for privacy risks', icon: '🔒' },
  { text: 'Analyze fairness and bias', icon: '⚖️' },
  { text: 'Detect security vulnerabilities', icon: '🛡️' },
  { text: 'Perform complete trust audit', icon: '🎯' },
];

export function ChatView() {
  const { messages, addMessage, processPrompt, isProcessing, uploadedFiles } = useApp();
  const [input, setInput] = useState('');
  const [showUpload, setShowUpload] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isProcessing) return;

    const prompt = input.trim();
    setInput('');
    addMessage(prompt);
    processPrompt(prompt);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  return (
    <div className="flex h-full flex-col">
      <div className="flex-1 overflow-y-auto scrollbar-thin">
        <div className="mx-auto max-w-3xl px-4 py-6">
          <AnimatePresence mode="popLayout">
            {messages.map((message, index) => (
              <ChatMessage
                key={message.id}
                message={message}
                isLast={index === messages.length - 1}
              />
            ))}
          </AnimatePresence>

          {isProcessing && (
            <motion.div
              className="flex items-center gap-3 py-4"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-surface-900 dark:bg-white">
                <Loader2 className="h-4 w-4 animate-spin text-white dark:text-surface-900" />
              </div>
              <div className="flex items-center gap-2 text-sm text-surface-500">
                <Sparkles className="h-4 w-4" />
                <span>Analyzing with AI agents...</span>
              </div>
            </motion.div>
          )}

          <div ref={messagesEndRef} />
        </div>
      </div>

      <div className="flex-shrink-0 border-t border-surface-200 bg-white px-4 py-4 transition-colors dark:border-surface-800 dark:bg-surface-900">
        <div className="mx-auto max-w-3xl space-y-3">
          {messages.length <= 1 && uploadedFiles.length === 0 && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="grid grid-cols-2 gap-2"
            >
              {suggestedPrompts.map((prompt, index) => (
                <button
                  key={prompt.text}
                  onClick={() => setInput(prompt.text)}
                  className="flex items-center gap-3 rounded-lg border border-surface-200 bg-surface-50 px-4 py-3 text-left text-sm transition-all hover:border-surface-300 hover:bg-surface-100 dark:border-surface-700 dark:bg-surface-800 dark:hover:border-surface-600 dark:hover:bg-surface-700"
                >
                  <span className="text-lg">{prompt.icon}</span>
                  <span className="text-surface-700 dark:text-surface-300">{prompt.text}</span>
                </button>
              ))}
            </motion.div>
          )}

          <AnimatePresence>
            {showUpload && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
              >
                <FileUpload />
              </motion.div>
            )}
          </AnimatePresence>

          {uploadedFiles.length > 0 && !showUpload && (
            <div className="flex items-center gap-2 rounded-lg bg-surface-100 px-3 py-2 dark:bg-surface-800">
              <Paperclip className="h-4 w-4 text-surface-500" />
              <span className="text-sm text-surface-600 dark:text-surface-400">
                {uploadedFiles.length} file{uploadedFiles.length > 1 ? 's' : ''} attached
              </span>
              <button
                onClick={() => setShowUpload(true)}
                className="ml-auto text-xs text-primary-500 hover:text-primary-600"
              >
                View
              </button>
            </div>
          )}

          <form onSubmit={handleSubmit} className="relative">
            <div className="flex items-end gap-2 rounded-xl border border-surface-200 bg-surface-50 p-2 transition-colors focus-within:border-surface-300 focus-within:bg-white dark:border-surface-700 dark:bg-surface-800 dark:focus-within:border-surface-600 dark:focus-within:bg-surface-850">
              <button
                type="button"
                onClick={() => setShowUpload(!showUpload)}
                className={`flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-lg transition-colors ${
                  showUpload || uploadedFiles.length > 0
                    ? 'bg-surface-900 text-white dark:bg-white dark:text-surface-900'
                    : 'text-surface-400 hover:bg-surface-200 hover:text-surface-600 dark:hover:bg-surface-700 dark:hover:text-surface-300'
                }`}
              >
                <Paperclip className="h-5 w-5" />
              </button>

              <textarea
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Ask about privacy, bias, security, or compliance..."
                className="flex-1 resize-none bg-transparent px-1 py-2 text-surface-900 placeholder-surface-400 focus:outline-none dark:text-surface-100 dark:placeholder-surface-500"
                rows={1}
                style={{ height: 'auto', minHeight: '40px', maxHeight: '200px' }}
                disabled={isProcessing}
              />

              <motion.button
                type="submit"
                disabled={!input.trim() || isProcessing}
                className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-lg bg-surface-900 text-white transition-colors hover:bg-surface-800 disabled:bg-surface-200 disabled:text-surface-400 dark:bg-white dark:text-surface-900 dark:hover:bg-surface-100 dark:disabled:bg-surface-700 dark:disabled:text-surface-500"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <Send className="h-4 w-4" />
              </motion.button>
            </div>
          </form>

          <p className="text-center text-xs text-surface-400">
            Trust AI — Ethical AI Platform. Stay safe with AI.
          </p>
        </div>
      </div>
    </div>
  );
}
