import { motion } from 'framer-motion';
import { Moon, Sun, Bell, Shield, Database, Globe, Key, Monitor, CheckCircle } from 'lucide-react';
import { useApp } from '../context/AppContext';

export function SettingsView() {
  const { isDarkMode, toggleDarkMode } = useApp();

  const settingsSections = [
    {
      title: 'Appearance',
      icon: Monitor,
      settings: [
        {
          name: 'Dark Mode',
          description: 'Use dark theme',
          control: 'toggle',
          value: isDarkMode,
          onChange: toggleDarkMode,
        },
        {
          name: 'Animations',
          description: 'Enable smooth transitions',
          control: 'toggle',
          value: true,
          onChange: () => {},
        },
      ],
    },
    {
      title: 'Notifications',
      icon: Bell,
      settings: [
        {
          name: 'Email Alerts',
          description: 'High-risk finding alerts',
          control: 'toggle',
          value: true,
          onChange: () => {},
        },
        {
          name: 'Weekly Reports',
          description: 'Summary of trust audits',
          control: 'toggle',
          value: true,
          onChange: () => {},
        },
      ],
    },
    {
      title: 'Security',
      icon: Shield,
      settings: [
        {
          name: 'Two-Factor Auth',
          description: 'Require 2FA',
          control: 'toggle',
          value: false,
          onChange: () => {},
        },
        {
          name: 'Session Timeout',
          description: 'Auto-logout after',
          control: 'select',
          value: '30',
          options: ['15', '30', '60', '120'],
        },
      ],
    },
    {
      title: 'Data',
      icon: Database,
      settings: [
        {
          name: 'Retention',
          description: 'Keep audit history',
          control: 'select',
          value: '90',
          options: ['30', '60', '90', '180'],
        },
        {
          name: 'Anonymize',
          description: 'Remove personal data from results',
          control: 'toggle',
          value: true,
          onChange: () => {},
        },
      ],
    },
  ];

  return (
    <div className="h-full overflow-y-auto scrollbar-thin">
      <div className="mx-auto max-w-3xl px-6 py-6 space-y-6">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <h1 className="text-xl font-semibold text-surface-900 dark:text-surface-100">
            Settings
          </h1>
          <p className="mt-1 text-sm text-surface-500">
            Configure your preferences
          </p>
        </motion.div>

        {settingsSections.map((section, sectionIndex) => {
          const SectionIcon = section.icon;
          return (
            <motion.section
              key={section.title}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: sectionIndex * 0.05 }}
              className="card p-5"
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-surface-100 dark:bg-surface-800">
                  <SectionIcon className="h-4 w-4 text-surface-600 dark:text-surface-400" />
                </div>
                <h2 className="font-semibold text-surface-900 dark:text-surface-100">
                  {section.title}
                </h2>
              </div>

              <div className="space-y-3">
                {section.settings.map((setting, settingIndex) => (
                  <div
                    key={setting.name}
                    className="flex items-center justify-between rounded-lg bg-surface-50 px-4 py-3 dark:bg-surface-800"
                  >
                    <div>
                      <p className="text-sm font-medium text-surface-900 dark:text-surface-100">
                        {setting.name}
                      </p>
                      <p className="text-xs text-surface-500">{setting.description}</p>
                    </div>

                    {setting.control === 'toggle' && (
                      <button
                        onClick={setting.onChange}
                        className={`relative h-5 w-9 rounded-full transition-colors ${
                          setting.value
                            ? 'bg-surface-900 dark:bg-white'
                            : 'bg-surface-300 dark:bg-surface-600'
                        }`}
                      >
                        <motion.div
                          className="absolute top-0.5 left-0.5 h-4 w-4 rounded-full bg-white dark:bg-surface-900 shadow"
                          animate={{ x: setting.value ? 16 : 0 }}
                          transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                        />
                      </button>
                    )}

                    {setting.control === 'select' && (
                      <select
                        value={setting.value}
                        className="rounded border border-surface-200 bg-white px-2 py-1 text-sm dark:border-surface-700 dark:bg-surface-700"
                      >
                        {setting.options?.map((opt) => (
                          <option key={opt} value={opt}>
                            {opt} {opt === '15' || opt === '30' || opt === '60' || opt === '120' ? 'min' : 'days'}
                          </option>
                        ))}
                      </select>
                    )}
                  </div>
                ))}
              </div>
            </motion.section>
          );
        })}

        <motion.section
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="card p-5"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-surface-100 dark:bg-surface-800">
              <Globe className="h-4 w-4 text-surface-600 dark:text-surface-400" />
            </div>
            <h2 className="font-semibold text-surface-900 dark:text-surface-100">
              Compliance Standards
            </h2>
          </div>

          <div className="grid grid-cols-2 gap-2">
            {['NIST AI RMF', 'OECD AI Principles', 'EU AI Act', 'UNESCO AI Ethics'].map((std) => (
              <div
                key={std}
                className="flex items-center gap-2 rounded-lg bg-surface-50 px-3 py-2 dark:bg-surface-800"
              >
                <CheckCircle className="h-4 w-4 text-success-500" />
                <span className="text-sm text-surface-700 dark:text-surface-300">{std}</span>
              </div>
            ))}
          </div>
        </motion.section>
      </div>
    </div>
  );
}
