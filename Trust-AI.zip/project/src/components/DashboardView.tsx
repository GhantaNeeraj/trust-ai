import { motion } from 'framer-motion';
import {
  Shield,
  Scale,
  Lock,
  FileCheck,
  Eye,
  ArrowRight,
  Sparkles,
  Users,
  CheckCircle,
  Zap,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

const agentConfig = [
  { id: 'privacy', name: 'Privacy', icon: Lock, color: 'bg-emerald-500', textColor: 'text-emerald-600' },
  { id: 'bias', name: 'Bias', icon: Scale, color: 'bg-blue-500', textColor: 'text-blue-600' },
  { id: 'security', name: 'Security', icon: Shield, color: 'bg-red-500', textColor: 'text-red-600' },
  { id: 'compliance', name: 'Compliance', icon: FileCheck, color: 'bg-amber-500', textColor: 'text-amber-600' },
  { id: 'explainability', name: 'Explainability', icon: Eye, color: 'bg-cyan-500', textColor: 'text-cyan-600' },
];

export function DashboardView() {
  const { trustScore, setCurrentView } = useApp();

  return (
    <div className="h-full overflow-y-auto scrollbar-thin">
      <div className="mx-auto max-w-4xl px-6 py-12">
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <div className="flex justify-center mb-6">
            <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-surface-900 dark:bg-white">
              <Shield className="h-8 w-8 text-white dark:text-surface-900" />
            </div>
          </div>
          <h1 className="text-4xl font-semibold tracking-tight text-surface-900 dark:text-surface-100 mb-3">
            Trust AI
          </h1>
          <p className="text-xl text-surface-500 dark:text-surface-400 font-medium mb-4">
            Ethical AI Platform
          </p>
          <div className="inline-flex items-center gap-2 rounded-full border border-surface-200 bg-surface-50 px-4 py-2 dark:border-surface-700 dark:bg-surface-800">
            <Shield className="h-4 w-4 text-surface-400" />
            <p className="text-sm font-medium text-surface-600 dark:text-surface-400">
              Stay safe with AI
            </p>
          </div>

          {/* Description */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="mt-8 max-w-2xl mx-auto"
          >
            <p className="text-base text-surface-500 dark:text-surface-400 leading-relaxed">
              Trust AI is an ethical AI platform that detects bias, privacy risks, security vulnerabilities, and compliance issues in your AI systems. Built by over 100 engineers, our multi-agent framework ensures your AI remains safe, transparent, and accountable.
            </p>
          </motion.div>

          <div className="mt-8 flex items-center justify-center gap-3">
            <motion.button
              onClick={() => setCurrentView('chat')}
              className="inline-flex items-center gap-2 rounded-xl bg-surface-900 px-6 py-3 text-sm font-medium text-white transition-colors hover:bg-surface-800 dark:bg-white dark:text-surface-900 dark:hover:bg-surface-100"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Sparkles className="h-4 w-4" />
              Start Analysis
              <ArrowRight className="h-4 w-4" />
            </motion.button>
            <motion.button
              onClick={() => setCurrentView('agents')}
              className="inline-flex items-center gap-2 rounded-xl border border-surface-200 bg-white px-6 py-3 text-sm font-medium text-surface-700 transition-colors hover:bg-surface-50 dark:border-surface-700 dark:bg-surface-800 dark:text-surface-300 dark:hover:bg-surface-700"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Zap className="h-4 w-4" />
              Explore Agents
            </motion.button>
          </div>
        </motion.div>

        {/* Trust Score Overview */}
        {trustScore && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="card p-6 mb-10"
          >
            <div className="flex items-center justify-between mb-6">
              <div>
                <p className="text-sm text-surface-500 dark:text-surface-400">Trust Score</p>
                <div className="flex items-baseline gap-2">
                  <span className="text-4xl font-bold text-surface-900 dark:text-surface-100">
                    {Math.round(trustScore.overall)}
                  </span>
                  <span className="text-lg text-surface-400">/100</span>
                </div>
              </div>
              <div className="text-right">
                <span
                  className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-sm font-medium ${
                    trustScore.overall >= 80
                      ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-900/20 dark:text-emerald-400'
                      : trustScore.overall >= 50
                        ? 'bg-amber-50 text-amber-700 dark:bg-amber-900/20 dark:text-amber-400'
                        : 'bg-red-50 text-red-700 dark:bg-red-900/20 dark:text-red-400'
                  }`}
                >
                  <CheckCircle className="h-4 w-4" />
                  {trustScore.overall >= 80 ? 'Safe' : trustScore.overall >= 50 ? 'Medium Risk' : 'High Risk'}
                </span>
              </div>
            </div>

            <div className="h-4 w-full rounded-full bg-surface-200 dark:bg-surface-700 overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${trustScore.overall}%` }}
                transition={{ duration: 1, ease: 'easeOut' }}
                className={`h-full rounded-full ${
                  trustScore.overall >= 80
                    ? 'bg-gradient-to-r from-emerald-400 to-emerald-500'
                    : trustScore.overall >= 50
                      ? 'bg-gradient-to-r from-amber-400 to-amber-500'
                      : 'bg-gradient-to-r from-red-400 to-red-500'
                }`}
              />
            </div>
          </motion.div>
        )}

        {/* Agent Cards */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 mb-10"
        >
          {agentConfig.map((agent, index) => {
            const Icon = agent.icon;

            return (
              <motion.div
                key={agent.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.35 + index * 0.05 }}
                className="card p-4 text-center cursor-pointer transition-all hover:shadow-soft"
                onClick={() => setCurrentView('agents')}
              >
                <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${agent.color} mx-auto mb-3`}>
                  <Icon className="h-5 w-5 text-white" />
                </div>
                <p className="text-sm font-medium text-surface-900 dark:text-surface-100">{agent.name}</p>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Platform Stats */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-4"
        >
          {[
            {
              label: 'AI Engineers',
              value: '100+',
              description: 'World-class experts in responsible AI',
              icon: Users,
            },
            {
              label: 'AI Agents',
              value: '5',
              description: 'Privacy, Bias, Security, Compliance, Explainability',
              icon: Shield,
            },
            {
              label: 'Compliance Standards',
              value: '4+',
              description: 'NIST, OECD, EU AI Act, UNESCO',
              icon: CheckCircle,
            },
          ].map((stat, index) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.55 + index * 0.05 }}
                className="card p-5"
              >
                <div className="flex items-center gap-3 mb-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-surface-100 dark:bg-surface-800">
                    <Icon className="h-5 w-5 text-surface-600 dark:text-surface-400" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-surface-900 dark:text-surface-100">{stat.value}</p>
                    <p className="text-sm text-surface-500 dark:text-surface-400">{stat.label}</p>
                  </div>
                </div>
                <p className="text-xs text-surface-400 dark:text-surface-500">{stat.description}</p>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </div>
  );
}
