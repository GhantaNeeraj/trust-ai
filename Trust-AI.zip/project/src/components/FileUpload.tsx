import { useState, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Upload, FileText, FileSpreadsheet, X, AlertCircle } from 'lucide-react';
import Papa from 'papaparse';
import { useApp } from '../context/AppContext';
import { UploadedFile } from '../types';

export function FileUpload() {
  const { addUploadedFile, uploadedFiles, clearFiles, setCsvData } = useApp();
  const [isDragging, setIsDragging] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const processFile = useCallback(
    async (file: File) => {
      setError(null);

      const extension = file.name.split('.').pop()?.toLowerCase();
      const validExtensions = ['csv', 'pdf', 'txt'];

      if (!extension || !validExtensions.includes(extension)) {
        setError('File format not supported. Please upload CSV, PDF, or TXT files.');
        return;
      }

      const fileType = extension as 'csv' | 'pdf' | 'text';

      try {
        let content = '';

        if (fileType === 'csv') {
          const text = await file.text();
          content = text;
          Papa.parse(text, {
            complete: (results) => {
              if (results.data && Array.isArray(results.data)) {
                setCsvData(results.data as string[][]);
              }
            },
            skipEmptyLines: true,
          });
        } else if (fileType === 'pdf') {
          content = `[PDF File: ${file.name}]`;
        } else {
          content = await file.text();
        }

        const uploadedFile: UploadedFile = {
          name: file.name,
          type: fileType,
          content,
          size: file.size,
        };

        addUploadedFile(uploadedFile);
      } catch (err) {
        setError('Failed to process file. Please try again.');
      }
    },
    [addUploadedFile, setCsvData]
  );

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setIsDragging(false);
      const files = e.dataTransfer.files;
      if (files.length > 0) {
        processFile(files[0]);
      }
    },
    [processFile]
  );

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleFileInput = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const files = e.target.files;
      if (files && files.length > 0) {
        processFile(files[0]);
      }
    },
    [processFile]
  );

  const getFileIcon = (type: string) => {
    switch (type) {
      case 'csv':
        return <FileSpreadsheet className="h-4 w-4" />;
      case 'pdf':
        return <FileText className="h-4 w-4" />;
      default:
        return <FileText className="h-4 w-4" />;
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <div className="space-y-3">
      <motion.div
        className={`file-drop-zone ${isDragging ? 'border-surface-400 bg-surface-100 dark:bg-surface-700' : ''}`}
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onClick={() => fileInputRef.current?.click()}
        whileHover={{ scale: 1.005 }}
        whileTap={{ scale: 0.995 }}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept=".csv,.pdf,.txt"
          onChange={handleFileInput}
          className="hidden"
        />

        <motion.div
          animate={{ y: isDragging ? 3 : 0 }}
          transition={{ duration: 0.15 }}
          className="flex items-center justify-center gap-2"
        >
          <Upload className={`h-5 w-5 ${isDragging ? 'text-surface-600' : 'text-surface-400'}`} />
          <span className="text-sm font-medium text-surface-600 dark:text-surface-400">
            {isDragging ? 'Drop file here' : 'Upload CSV, PDF, or TXT'}
          </span>
        </motion.div>
      </motion.div>

      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="flex items-center gap-2 rounded-lg bg-danger-50 px-3 py-2 text-sm text-danger-600 dark:bg-danger-900/20 dark:text-danger-400"
          >
            <AlertCircle className="h-4 w-4 flex-shrink-0" />
            <span>{error}</span>
            <button onClick={() => setError(null)} className="ml-auto">
              <X className="h-4 w-4" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {uploadedFiles.length > 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="space-y-2"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-surface-500">
                Attached ({uploadedFiles.length})
              </span>
              <button
                onClick={clearFiles}
                className="text-xs text-surface-400 hover:text-danger-500"
              >
                Clear
              </button>
            </div>

            {uploadedFiles.map((file, index) => (
              <motion.div
                key={file.name}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                transition={{ delay: index * 0.03 }}
                className="flex items-center gap-3 rounded-lg bg-surface-100 p-2.5 dark:bg-surface-800"
              >
                <div className="flex h-8 w-8 items-center justify-center rounded bg-surface-900 dark:bg-white">
                  {getFileIcon(file.type)}
                  <span className="text-white dark:text-surface-900" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="truncate text-sm font-medium text-surface-700 dark:text-surface-300">
                    {file.name}
                  </p>
                  <p className="text-xs text-surface-400">
                    {file.type.toUpperCase()} - {formatFileSize(file.size)}
                  </p>
                </div>
                <span className="rounded-full bg-success-100 dark:bg-success-900/30 px-2 py-0.5 text-xs font-medium text-success-700 dark:text-success-400">
                  Ready
                </span>
              </motion.div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
