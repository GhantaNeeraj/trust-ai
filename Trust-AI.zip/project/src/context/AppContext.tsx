import React, { createContext, useContext, useState, useCallback, ReactNode } from 'react';
import { AgentResult, AgentResultsMap, TrustScore, UploadedFile, ChatMessage, ViewType } from '../types';
import {
  detectAgentFromPrompt,
  runSingleAgent,
  reportAgent,
  getTrustGrade,
} from '../utils/agents';

interface AppState {
  messages: ChatMessage[];
  currentView: ViewType;
  uploadedFiles: UploadedFile[];
  csvData: string[][] | null;
  // Per-agent results stored in isolation — bias results never bleed into privacy slot, etc.
  agentResultsMap: AgentResultsMap;
  trustScore: TrustScore | null;
  isProcessing: boolean;
  isDarkMode: boolean;
}

interface AppContextType extends AppState {
  addMessage: (content: string) => void;
  setCurrentView: (view: ViewType) => void;
  addUploadedFile: (file: UploadedFile) => void;
  clearFiles: () => void;
  setCsvData: (data: string[][] | null) => void;
  toggleDarkMode: () => void;
  processPrompt: (prompt: string) => void;
}

const AppContext = createContext<AppContextType | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      role: 'assistant',
      content: 'Welcome to Trust AI — your Ethical AI Platform.\n\nStay safe with AI. I can help you analyze AI systems, datasets, and documents for:\n\n- **Privacy Risks** — Detect PII and sensitive data\n- **Bias Detection** — Analyze fairness and representation\n- **Security Vulnerabilities** — Identify injection attacks and credential leaks\n- **Compliance** — Check governance and ethical standards\n- **Trust Audits** — Complete AI system assessments\n\nUpload a CSV or PDF file, or ask me a question to get started.',
      timestamp: new Date(),
    },
  ]);
  const [currentView, setCurrentView] = useState<ViewType>('chat');
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);
  const [csvData, setCsvData] = useState<string[][] | null>(null);
  const [agentResultsMap, setAgentResultsMap] = useState<AgentResultsMap>({});
  const [trustScore, setTrustScore] = useState<TrustScore | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);

  const addMessage = useCallback((content: string) => {
    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content,
      timestamp: new Date(),
    };
    setMessages(prev => [...prev, userMessage]);
  }, []);

  const addUploadedFile = useCallback((file: UploadedFile) => {
    setUploadedFiles(prev => [...prev, file]);
  }, []);

  const clearFiles = useCallback(() => {
    setUploadedFiles([]);
    setCsvData(null);
  }, []);

  const toggleDarkMode = useCallback(() => {
    setIsDarkMode(prev => !prev);
  }, []);

  const processPrompt = useCallback((prompt: string) => {
    setIsProcessing(true);

    setTimeout(() => {
      const agentType = detectAgentFromPrompt(prompt);

      const textToAnalyze = uploadedFiles.length > 0
        ? uploadedFiles.map(f => f.content).join('\n\n') + '\n\n' + prompt
        : prompt;

      if (agentType !== 'all') {
        // Single-agent: run ONLY that one agent, write ONLY to its slot in the map.
        // No other agent's slot is touched — zero overlap guaranteed.
        const singleResult = runSingleAgent(agentType, textToAnalyze, csvData || undefined);

        setAgentResultsMap(prev => ({ ...prev, [agentType]: singleResult }));

        const agentName =
          agentType === 'privacy' ? 'Privacy Agent' :
          agentType === 'bias' ? 'Bias Detection Agent' :
          agentType === 'security' ? 'Security Agent' :
          agentType === 'compliance' ? 'Compliance Agent' :
          'Explainability Agent';

        let responseText = `## ${agentName} Analysis Complete\n\n`;
        responseText += `**${singleResult.agent} Score: ${singleResult.score}/100**\n`;
        responseText += `- **Risk Level:** ${singleResult.risk}\n\n`;

        if (singleResult.agent === 'Privacy') {
          responseText += `- **Shareability:** ${singleResult.shareability}\n`;
          if (singleResult.sensitiveDataDetected && singleResult.sensitiveDataDetected.length > 0) {
            responseText += `- **Sensitive Data Detected:**\n`;
            singleResult.sensitiveDataDetected.forEach(d => {
              responseText += `  - ${d}\n`;
            });
          }
          responseText += `\n`;
        }

        responseText += `**Findings:**\n`;
        singleResult.findings.forEach(f => {
          responseText += `- ${f}\n`;
        });
        responseText += `\n**Recommendations:**\n`;
        singleResult.recommendations.forEach(r => {
          responseText += `- ${r}\n`;
        });

        const score: TrustScore = {
          overall: singleResult.score,
          privacy: agentType === 'privacy' ? singleResult.score : (trustScore?.privacy ?? 0),
          bias: agentType === 'bias' ? singleResult.score : (trustScore?.bias ?? 0),
          security: agentType === 'security' ? singleResult.score : (trustScore?.security ?? 0),
          compliance: agentType === 'compliance' ? singleResult.score : (trustScore?.compliance ?? 0),
          explainability: agentType === 'explainability' ? singleResult.score : (trustScore?.explainability ?? 0),
          grade: getTrustGrade(singleResult.score),
          timestamp: new Date(),
        };

        const assistantMessage: ChatMessage = {
          id: (Date.now() + 1).toString(),
          role: 'assistant',
          content: responseText,
          timestamp: new Date(),
          agentResults: [singleResult],
          trustScore: score,
          singleAgent: true,
        };

        setMessages(prev => [...prev, assistantMessage]);
        setTrustScore(score);
        setIsProcessing(false);
        return;
      }

      // Full audit: Report Agent runs all agents, writes each to its own slot.
      const report = reportAgent(textToAnalyze, csvData || undefined);
      const results = report.results;

      const newMap: AgentResultsMap = {};
      results.forEach(r => {
        const key = r.agent === 'Bias Detection' ? 'bias' :
          r.agent.toLowerCase() as Exclude<typeof agentType, 'all'>;
        newMap[key as keyof AgentResultsMap] = r;
      });
      setAgentResultsMap(newMap);

      const privacyResult = results.find(r => r.agent === 'Privacy');
      const biasResult = results.find(r => r.agent === 'Bias Detection');
      const securityResult = results.find(r => r.agent === 'Security');
      const complianceResult = results.find(r => r.agent === 'Compliance');
      const explainabilityResult = results.find(r => r.agent === 'Explainability');

      const score: TrustScore = {
        overall: report.trustScore,
        privacy: privacyResult?.score ?? 0,
        bias: biasResult?.score ?? 0,
        security: securityResult?.score ?? 0,
        compliance: complianceResult?.score ?? 0,
        explainability: explainabilityResult?.score ?? 0,
        grade: report.grade,
        timestamp: new Date(),
      };

      const assistantMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: report.combinedReport,
        timestamp: new Date(),
        agentResults: results,
        trustScore: score,
        singleAgent: false,
      };

      setMessages(prev => [...prev, assistantMessage]);
      setTrustScore(score);
      setIsProcessing(false);
    }, 1500);
  }, [uploadedFiles, csvData, trustScore]);

  return (
    <AppContext.Provider
      value={{
        messages,
        currentView,
        uploadedFiles,
        csvData,
        agentResultsMap,
        trustScore,
        isProcessing,
        isDarkMode,
        addMessage,
        setCurrentView,
        addUploadedFile,
        clearFiles,
        setCsvData,
        toggleDarkMode,
        processPrompt,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
