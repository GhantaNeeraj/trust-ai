declare module 'papaparse' {
  interface ParseConfig<T = unknown> {
    complete?: (results: ParseResult<T>) => void;
    error?: (error: Error) => void;
    header?: boolean;
    skipEmptyLines?: boolean | 'greedy';
    preview?: number;
    dynamicTyping?: boolean;
    comments?: boolean | string;
    fastMode?: boolean;
    transform?: (value: string, field: string | number) => unknown;
  }

  interface ParseResult<T = unknown> {
    data: T;
    errors: ParseError[];
    meta: ParseMeta;
  }

  interface ParseError {
    type: string;
    code: string;
    message: string;
    row?: number;
  }

  interface ParseMeta {
    delimiter: string;
    linebreak: string;
    truncated: boolean;
    cursor?: number;
    aborted?: boolean;
    fields?: string[];
  }

  interface PapaParse {
    parse<T = unknown>(input: string | File, config?: ParseConfig<T>): void;
    unparse(data: unknown, config?: object): string;
  }

  const Papa: PapaParse;
  export default Papa;
}
