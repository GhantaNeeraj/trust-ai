export type AgentType = 'privacy' | 'bias' | 'security' | 'compliance' | 'explainability' | 'all';

export type ViewType = 'chat' | 'dashboard' | 'agents' | 'settings' | 'reports';

export type Shareability = 'NOT SHAREABLE' | 'SHARE WITH CAUTION' | 'SAFE TO SHARE';

export interface AgentResult {
  agent: string;
  score: number;
  risk: 'Safe' | 'Medium Risk' | 'High Risk';
  findings: string[];
  recommendations: string[];
  details?: Record<string, unknown>;
  // Privacy-agent-only fields. Undefined on other agents.
  shareability?: Shareability;
  sensitiveDataDetected?: string[];
}

// Keyed by agent type — each agent's result is stored independently.
// No agent can read another agent's slot.
export type AgentResultsMap = Partial<Record<Exclude<AgentType, 'all'>, AgentResult>>;

export interface TrustScore {
  overall: number;
  privacy: number;
  bias: number;
  security: number;
  compliance: number;
  explainability: number;
  grade: string;
  timestamp: Date;
}

export interface UploadedFile {
  name: string;
  type: 'csv' | 'pdf' | 'text';
  content: string;
  size: number;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: Date;
  agentResults?: AgentResult[];
  trustScore?: TrustScore;
  singleAgent?: boolean;
}
