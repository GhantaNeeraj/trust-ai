import { AgentResult, AgentType } from '../types';

// ============================================================================
// SHARED REGEX PATTERNS
// ============================================================================
const privacyPatterns = {
  email: /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g,
  phone: /(?:\+?\d[\d\s-]{8,}\d)/g,
  aadhaar: /\b\d{4}[\s-]?\d{4}[\s-]?\d{4}\b/g,
  pan: /\b[A-Z]{5}[0-9]{4}[A-Z]\b/g,
  dob: /\b\d{1,2}[\/\-.]\d{1,2}[\/\-.]\d{2,4}\b/g,
  password: /\b(?:password|pwd|passcode|passwd)\s*[:=]\s*\S+/gi,
  bankAccount: /\b(?:account\s*(?:no|number)?|acct)\s*[:#]?\s*\d{9,18}\b/gi,
  creditCard: /\b(?:\d[ -]*?){13,16}\b/g,
  address: /\b(?:\d+\s+[\w\s]+(?:street|st|avenue|ave|road|rd|lane|ln|drive|dr|blvd|boulevard))\b/gi,
  loginId: /\b(?:login|username|user[_\s-]?id|user)\s*[:=]\s*\S+/gi,
  apiKeyPrivacy: /\b(?:api[_\s-]?key|apikey)\s*[:=]\s*\S+/gi,
};

const securityPatterns = {
  apiKey: /\b(?:api[_\s-]?key|apikey)\s*[:=]\s*\S+/gi,
  token: /\b(?:token|bearer|access[_\s-]?token|auth[_\s-]?token)\s*[:=]\s*\S+/gi,
  secret: /\b(?:secret|private[_\s-]?key|client[_\s-]?secret)\s*[:=]\s*\S+/gi,
  injection:
    /ignore\s+(?:previous|all|prior)\s+(?:instructions?|rules?|prompts?)|bypass\s+(?:restrictions?|safety|filters?)|reveal\s+(?:hidden|system)\s+prompt|act\s+as\s+(?:admin|administrator|root|dan)|forget\s+(?:everything|all\s+previous)|you\s+are\s+(?:now|free|django)/gi,
  jailbreak:
    /(?:new\s+instruction|disregard\s+(?:the\s+above|previous)|override\s+safety|jailbreak|unrestricted\s+mode|developer\s+mode)/gi,
  credentials: /\b(?:login|password|username|user[_\s-]?id)\s*[:=]\s*\S+/gi,
  malicious: /\b(?:malware|virus|exploit|payload|backdoor|trojan|ransomware)\b/gi,
};

// Sensitivity tiers for shareability logic
type SensitivityTier = 'high' | 'medium' | 'minimal';

// ============================================================================
// AGENT ROUTER — multi-agent rule
// ============================================================================
export function detectAgentFromPrompt(prompt: string): AgentType {
  const p = prompt.toLowerCase();

  if (
    p.includes('full trust audit') ||
    p.includes('complete ai audit') ||
    p.includes('complete trust audit') ||
    p.includes('analyze all risks') ||
    p.includes('full audit') ||
    p.includes('run all') ||
    p.includes('complete audit')
  ) {
    return 'all';
  }

  if (p.includes('compliance') || p.includes('governance') || p.includes('regulation')) {
    return 'compliance';
  }
  if (p.includes('security') || p.includes('injection') || p.includes('jailbreak')) {
    return 'security';
  }
  if (p.includes('bias') || p.includes('fairness') || p.includes('discrimination') || p.includes('imbalance')) {
    return 'bias';
  }
  if (p.includes('privacy') || p.includes('sensitive') || p.includes('pii') || p.includes('shareable')) {
    return 'privacy';
  }
  if (p.includes('explain') || p.includes('why') || p.includes('transparency')) {
    return 'explainability';
  }

  // Default: full audit (ambiguous / open-ended prompts)
  return 'all';
}

// ============================================================================
// 1. PRIVACY AGENT — ONLY privacy analysis
// ============================================================================
interface PrivacyResult extends AgentResult {
  shareability: 'NOT SHAREABLE' | 'SHARE WITH CAUTION' | 'SAFE TO SHARE';
  sensitiveDataDetected: string[];
}

export function privacyAgent(text: string): PrivacyResult {
  const findings: string[] = [];
  const recommendations: string[] = [];
  const sensitiveDataDetected: string[] = [];
  const details: Record<string, number> = {};
  let totalRiskPoints = 0;
  let highestTier: SensitivityTier = 'minimal';

  // --- Minimal sensitivity (-10 each) ---
  const emails = text.match(privacyPatterns.email) || [];
  if (emails.length) {
    totalRiskPoints += emails.length * 10;
    findings.push(`Email addresses detected: ${emails.length} (-${emails.length * 10})`);
    sensitiveDataDetected.push('Email');
    details.emails = emails.length;
    if (highestTier === 'minimal') highestTier = 'minimal';
  }

  const phones = text.match(privacyPatterns.phone) || [];
  if (phones.length) {
    totalRiskPoints += phones.length * 10;
    findings.push(`Phone numbers detected: ${phones.length} (-${phones.length * 10})`);
    sensitiveDataDetected.push('Phone Number');
    details.phones = phones.length;
  }

  const dobs = text.match(privacyPatterns.dob) || [];
  if (dobs.length) {
    totalRiskPoints += dobs.length * 10;
    findings.push(`Date of birth patterns detected: ${dobs.length} (-${dobs.length * 10})`);
    sensitiveDataDetected.push('DOB');
    details.dobs = dobs.length;
  }

  const loginIds = text.match(privacyPatterns.loginId) || [];
  if (loginIds.length) {
    totalRiskPoints += loginIds.length * 10;
    findings.push(`Login / User IDs detected: ${loginIds.length} (-${loginIds.length * 10})`);
    sensitiveDataDetected.push('Login ID');
    details.loginIds = loginIds.length;
  }

  const addresses = text.match(privacyPatterns.address) || [];
  if (addresses.length) {
    totalRiskPoints += addresses.length * 20;
    findings.push(`Address indicators detected: ${addresses.length} (-${addresses.length * 20})`);
    sensitiveDataDetected.push('Address');
    details.addresses = addresses.length;
    if (highestTier !== 'high') highestTier = 'medium';
  }

  // --- Medium sensitivity (-20 each) ---
  const pans = text.match(privacyPatterns.pan) || [];
  if (pans.length) {
    totalRiskPoints += pans.length * 20;
    findings.push(`PAN numbers detected: ${pans.length} (-${pans.length * 20})`);
    sensitiveDataDetected.push('PAN');
    details.pans = pans.length;
    if (highestTier !== 'high') highestTier = 'medium';
  }

  // --- High sensitivity (-30 to -50 each) ---
  const aadhaars = text.match(privacyPatterns.aadhaar) || [];
  if (aadhaars.length) {
    totalRiskPoints += aadhaars.length * 30;
    findings.push(`Aadhaar numbers detected: ${aadhaars.length} (-${aadhaars.length * 30})`);
    sensitiveDataDetected.push('Aadhaar Number');
    details.aadhaars = aadhaars.length;
    highestTier = 'high';
  }

  const bankAccounts = text.match(privacyPatterns.bankAccount) || [];
  if (bankAccounts.length) {
    totalRiskPoints += bankAccounts.length * 30;
    findings.push(`Bank account numbers detected: ${bankAccounts.length} (-${bankAccounts.length * 30})`);
    sensitiveDataDetected.push('Bank Account');
    details.bankAccounts = bankAccounts.length;
    highestTier = 'high';
  }

  const creditCards = text.match(privacyPatterns.creditCard) || [];
  if (creditCards.length) {
    totalRiskPoints += creditCards.length * 30;
    findings.push(`Credit card numbers detected: ${creditCards.length} (-${creditCards.length * 30})`);
    sensitiveDataDetected.push('Credit Card');
    details.creditCards = creditCards.length;
    highestTier = 'high';
  }

  const passwords = text.match(privacyPatterns.password) || [];
  if (passwords.length) {
    totalRiskPoints += passwords.length * 50;
    findings.push(`Passwords detected: ${passwords.length} (-${passwords.length * 50})`);
    sensitiveDataDetected.push('Password');
    details.passwords = passwords.length;
    highestTier = 'high';
  }

  const apiKeys = text.match(privacyPatterns.apiKeyPrivacy) || [];
  if (apiKeys.length) {
    totalRiskPoints += apiKeys.length * 50;
    findings.push(`API keys detected: ${apiKeys.length} (-${apiKeys.length * 50})`);
    sensitiveDataDetected.push('API Key');
    details.apiKeys = apiKeys.length;
    highestTier = 'high';
  }

  // Context penalty: Password + Email together → account compromise risk
  if (details.emails && details.passwords) {
    totalRiskPoints += 20;
    findings.push('Context penalty: Password + Email together → account compromise risk (-20)');
    details.contextPenalty = 20;
  }

  // Formula: Privacy Score = 100 - Total Sensitive Risk Points
  let score = 100 - totalRiskPoints;
  score = Math.max(0, Math.min(100, score));

  const riskLevel = score >= 80 ? 'Safe' : score >= 50 ? 'Medium Risk' : 'High Risk';

  // Shareability logic per spec
  const shareability: PrivacyResult['shareability'] =
    highestTier === 'high'
      ? 'NOT SHAREABLE'
      : highestTier === 'medium'
        ? 'SHARE WITH CAUTION'
        : 'SAFE TO SHARE';

  // Recommendations (privacy-only)
  if (score === 100) {
    recommendations.push('No sensitive personal information detected.');
  } else {
    recommendations.push('Remove sensitive personal information before sharing with AI systems.');
  }
  if (details.emails) recommendations.push('Mask or hash email addresses before processing.');
  if (details.phones) recommendations.push('Remove or encrypt phone numbers.');
  if (details.aadhaars) recommendations.push('CRITICAL: Aadhaar numbers should never be shared with AI systems.');
  if (details.pans) recommendations.push('Remove PAN numbers from the dataset.');
  if (details.passwords) recommendations.push('Remove all password references immediately.');
  if (details.bankAccounts) recommendations.push('Anonymize bank account information.');
  if (details.creditCards) recommendations.push('Mask or tokenize credit card numbers.');
  if (details.apiKeys) recommendations.push('Never expose API keys in prompts or data.');

  return {
    agent: 'Privacy',
    score,
    risk: riskLevel,
    findings,
    recommendations,
    details,
    shareability,
    sensitiveDataDetected,
  };
}

// ============================================================================
// 2. BIAS DETECTION AGENT — ONLY fairness analysis
// ============================================================================
export function biasAgent(text: string, csvData?: string[][]): AgentResult {
  let score = 100;
  const findings: string[] = [];
  const details: Record<string, unknown> = {};

  const genderTerms = /\b(male|female|man|woman|boy|girl|he|she|him|her)\b/gi;
  const ageTerms = /\b(age|old|young|elderly|teenage|adult|child)\b/gi;
  const raceTerms = /\b(white|black|asian|hispanic|latino|african|european|indian|chinese)\b/gi;

  // Structured CSV analysis
  if (csvData && csvData.length > 1) {
    const headers = csvData[0];
    const rows = csvData.slice(1);

    const genderCol = headers.findIndex(h => /gender|sex/i.test(h));
    if (genderCol !== -1) {
      const values = rows.map(r => r[genderCol]?.toLowerCase()).filter(Boolean);
      const maleCount = values.filter(v => /male|^m$|man|boy/.test(v)).length;
      const femaleCount = values.filter(v => /female|^f$|woman|girl/.test(v)).length;

      if (maleCount > 0 && femaleCount > 0) {
        const ratio = Math.max(maleCount, femaleCount) / Math.min(maleCount, femaleCount);
        if (ratio > 2) {
          const penalty = Math.min(Math.round(ratio * 10), 30);
          score -= penalty;
          findings.push(`Gender imbalance detected (ratio ${ratio.toFixed(2)}:1) (-${penalty})`);
          details.genderImbalance = ratio;
        }
      } else if (maleCount > 0 || femaleCount > 0) {
        score -= 15;
        findings.push('Single-gender representation detected (-15)');
        details.singleGender = true;
      }
    }

    const missingRows = rows.filter(row =>
      row.some(cell => !cell || cell.trim() === '' || /na|null|n\/a/i.test(cell))
    ).length;
    const missingPct = rows.length > 0 ? (missingRows / rows.length) * 100 : 0;
    if (missingPct > 10) {
      const penalty = Math.min(Math.round(missingPct), 30);
      score -= penalty;
      findings.push(`Missing values: ${missingPct.toFixed(1)}% of rows (-${penalty})`);
      details.missingPercentage = Number(missingPct.toFixed(1));
    }

    // Class imbalance on a label column
    const labelCol = headers.findIndex(h => /label|class|outcome|target|result/i.test(h));
    if (labelCol !== -1) {
      const counts: Record<string, number> = {};
      rows.forEach(r => {
        const v = (r[labelCol] || '').toLowerCase();
        if (v) counts[v] = (counts[v] || 0) + 1;
      });
      const vals = Object.values(counts);
      if (vals.length > 1) {
        const ratio = Math.max(...vals) / Math.min(...vals);
        if (ratio > 3) {
          const penalty = 15;
          score -= penalty;
          findings.push(`Class imbalance detected (ratio ${ratio.toFixed(2)}:1) (-${penalty})`);
          details.classImbalance = ratio;
        }
      }
    }
  }

  // Unstructured text signals (fairness only)
  const gMatches = text.match(genderTerms) || [];
  if (gMatches.length) {
    findings.push(`Gender-related terms found: ${gMatches.length}`);
    details.genderTerms = gMatches.length;
  }
  const aMatches = text.match(ageTerms) || [];
  if (aMatches.length) {
    findings.push(`Age-related terms found: ${aMatches.length}`);
    details.ageTerms = aMatches.length;
  }
  const rMatches = text.match(raceTerms) || [];
  if (rMatches.length) {
    findings.push(`Demographic terms found: ${rMatches.length}`);
    details.demographicTerms = rMatches.length;
  }

  if (findings.length === 0) {
    findings.push('No significant bias indicators detected.');
  }

  score = Math.max(0, Math.min(100, score));
  const risk = score >= 80 ? 'Safe' : score >= 50 ? 'Medium Risk' : 'High Risk';

  const recommendations: string[] = [];
  if (score === 100) {
    recommendations.push('Dataset appears balanced. Continue monitoring.');
  } else {
    recommendations.push('Balance demographic representation in the dataset.');
  }
  if (details.genderImbalance) recommendations.push('Resample to reduce gender imbalance.');
  if (details.missingPercentage) recommendations.push('Impute or remove rows with missing values.');
  if (details.classImbalance) recommendations.push('Apply stratified sampling for class balance.');

  return {
    agent: 'Bias Detection',
    score,
    risk,
    findings,
    recommendations,
    details,
    // Extra context surfaced as a hint in the report renderer (not another agent's score).
    // Using details avoids leaking cross-agent scores into Bias's own output.
  };
}

// ============================================================================
// 3. SECURITY AGENT — ONLY security vulnerabilities / AI attacks
// ============================================================================
export function securityAgent(text: string): AgentResult {
  let score = 100;
  const findings: string[] = [];
  const details: Record<string, number> = {};

  const apiKeys = text.match(securityPatterns.apiKey) || [];
  if (apiKeys.length) {
    score -= 30;
    findings.push(`Exposed API key detected (-30)`);
    details.apiKeyFound = apiKeys.length;
  }

  const tokens = text.match(securityPatterns.token) || [];
  if (tokens.length) {
    score -= 25;
    findings.push(`Authentication token exposed (-25)`);
    details.tokenFound = tokens.length;
  }

  const secrets = text.match(securityPatterns.secret) || [];
  if (secrets.length) {
    score -= 30;
    findings.push(`Secret / private key exposed (-30)`);
    details.secretFound = secrets.length;
  }

  const injections = text.match(securityPatterns.injection) || [];
  if (injections.length) {
    const penalty = Math.min(injections.length * 30, 60);
    score -= penalty;
    findings.push(`Prompt injection attempt detected: ${injections.length} (-${penalty})`);
    details.injectionAttempts = injections.length;
  }

  const jailbreaks = text.match(securityPatterns.jailbreak) || [];
  if (jailbreaks.length) {
    const penalty = Math.min(jailbreaks.length * 25, 50);
    score -= penalty;
    findings.push(`Jailbreak attempt detected: ${jailbreaks.length} (-${penalty})`);
    details.jailbreakAttempts = jailbreaks.length;
  }

  const creds = text.match(securityPatterns.credentials) || [];
  if (creds.length) {
    score -= 15;
    findings.push(`Credential references detected (-15)`);
    details.credentialsFound = creds.length;
  }

  const malicious = text.match(securityPatterns.malicious) || [];
  if (malicious.length) {
    score -= 20;
    findings.push(`Malicious content indicators detected (-20)`);
    details.maliciousIndicators = malicious.length;
  }

  if (findings.length === 0) {
    findings.push('No security vulnerabilities detected.');
  }

  score = Math.max(0, Math.min(100, score));
  const risk = score >= 80 ? 'Safe' : score >= 50 ? 'Medium Risk' : 'High Risk';
  const threatLevel = score >= 80 ? 'Low' : score >= 50 ? 'Medium' : 'High';

  const recommendations: string[] = [];
  if (score === 100) {
    recommendations.push('No critical security vulnerabilities detected.');
  } else {
    recommendations.push('Remove exposed credentials and sanitize prompts.');
  }
  if (details.injectionAttempts) {
    recommendations.push('Sanitize inputs against prompt injection.');
    recommendations.push('Implement input validation and filtering.');
  }
  if (details.jailbreakAttempts) recommendations.push('Add output filtering to prevent policy violations.');
  if (details.apiKeyFound || details.tokenFound || details.secretFound) {
    recommendations.push('Use environment variables or a secret manager for credentials.');
  }

  return {
    agent: 'Security',
    score,
    risk,
    findings,
    recommendations,
    details,
  };
}

// ============================================================================
// 4. COMPLIANCE AGENT — ONLY governance / Responsible AI (RAG-backed)
// ============================================================================
// A lightweight in-process knowledge base of Responsible AI standards.
// In a production system this would be a real RAG retrieval over a vector store;
// here we embed a compact curated knowledge base so the agent is self-contained.
const RESPONSIBLE_AI_KB: { standard: string; criteria: RegExp; description: string }[] = [
  { standard: 'NIST AI RMF', criteria: /risk\s+management|governance|lifecycle|measure|manage/i, description: 'Govern, Map, Measure, Manage functions' },
  { standard: 'OECD AI Principles', criteria: /human[-\s]?centred|inclusive\s+growth|transparency|robustness|accountability/i, description: 'Inclusive growth, human-centred values, transparency, robustness, accountability' },
  { standard: 'EU AI Act', criteria: /high[-\s]?risk|risk\s+assessment|transparency\s+obligation|conformity/i, description: 'Risk-based tiers, transparency obligations, conformity assessment' },
  { standard: 'UNESCO AI Ethics', criteria: /human\s+dignity|sustainability|fairness|accountability|oversight/i, description: 'Human dignity, sustainability, fairness, accountability, oversight' },
];

export function complianceAgent(text: string): AgentResult {
  let score = 100;
  const findings: string[] = [];
  const details: Record<string, boolean> = {};

  const dimensions = [
    { key: 'transparency', label: 'Transparency', pattern: /explain|transparent|clear|understand|why|how|reason/i },
    { key: 'accountability', label: 'Accountability', pattern: /responsible|accountable|owner|audit|trace|log/i },
    { key: 'fairness', label: 'Fairness', pattern: /fair|unbiased|equal|equitable|justice|impartial/i },
    { key: 'oversight', label: 'Human Oversight', pattern: /human|oversight|control|review|approve|supervision/i },
    { key: 'ethics', label: 'Ethical Use', pattern: /ethical|moral|rights|consent|harm|safety|wellbeing/i },
  ];

  dimensions.forEach(dim => {
    if (dim.pattern.test(text)) {
      findings.push(`${dim.label} elements present.`);
    } else {
      score -= 15;
      findings.push(`${dim.label} not clearly addressed (-15).`);
      details[`${dim.key}Missing`] = true;
    }
  });

  // RAG-style retrieval: match standards from knowledge base
  const matchedStandards: string[] = [];
  for (const entry of RESPONSIBLE_AI_KB) {
    if (entry.criteria.test(text)) {
      findings.push(`Aligned with ${entry.standard}: ${entry.description}.`);
      matchedStandards.push(entry.standard);
    }
  }
  if (matchedStandards.length === 0) {
    findings.push('No specific Responsible AI standard referenced. Consider aligning with NIST AI RMF, OECD, EU AI Act, or UNESCO.');
  }

  score = Math.max(0, Math.min(100, score));
  const risk = score >= 80 ? 'Safe' : score >= 50 ? 'Medium Risk' : 'High Risk';
  const governanceStatus = score >= 80 ? 'Compliant' : score >= 50 ? 'Mostly Compliant' : 'Non-Compliant';

  const recommendations: string[] = [];
  if (score === 100) {
    recommendations.push('Governance documentation is comprehensive.');
  } else {
    recommendations.push('Add Responsible AI governance documentation.');
  }
  if (details.transparencyMissing) recommendations.push('Document AI system purpose and limitations clearly.');
  if (details.accountabilityMissing) recommendations.push('Establish clear accountability and ownership.');
  if (details.fairnessMissing) recommendations.push('Implement fairness testing and monitoring.');
  if (details.oversightMissing) recommendations.push('Ensure human oversight for high-risk decisions.');
  if (details.ethicsMissing) recommendations.push('Conduct regular ethical impact assessments.');

  return {
    agent: 'Compliance',
    score,
    risk,
    findings,
    recommendations,
    details,
  };
}

// ============================================================================
// 5. EXPLAINABILITY AGENT — ONLY explains why scores/risks were generated
// ============================================================================
export function explainabilityAgent(results: AgentResult[]): AgentResult {
  const explanations: string[] = [];

  results.forEach(result => {
    if (result.score < 100 && result.findings.length > 0) {
      const reasons = result.findings.slice(0, 3).join('; ');
      explanations.push(
        `${result.agent} score reduced to ${result.score} because: ${reasons}.`
      );
    } else if (result.score >= 80) {
      explanations.push(`${result.agent} is within acceptable range (${result.score}).`);
    }
  });

  if (explanations.length === 0) {
    explanations.push('All agent scores are within acceptable ranges.');
    explanations.push('No significant risk factors identified.');
  }

  // Explainability does NOT compute the trust score; only the Report Agent does.
  const avg = results.length > 0 ? Math.round(results.reduce((s, r) => s + r.score, 0) / results.length) : 100;
  const risk = avg >= 80 ? 'Safe' : avg >= 50 ? 'Medium Risk' : 'High Risk';

  return {
    agent: 'Explainability',
    score: avg,
    risk,
    findings: explanations,
    recommendations: [
      'Review individual agent reports for detailed findings.',
      'Address high-priority risks first.',
      'Document remediation steps taken.',
    ],
  };
}

// ============================================================================
// 6. REPORT GENERATION AGENT — ONLY combines outputs into final audit report
// ============================================================================
export function reportAgent(
  text: string,
  csvData?: string[][]
): { results: AgentResult[]; trustScore: number; grade: string; combinedReport: string } {
  // Run the 4 analysis agents (each strictly scoped, no overlap)
  const privacy = privacyAgent(text);
  const bias = biasAgent(text, csvData);
  const security = securityAgent(text);
  const compliance = complianceAgent(text);
  // Explainability runs on the 4 analysis results
  const explainability = explainabilityAgent([privacy, bias, security, compliance]);

  const results: AgentResult[] = [privacy, bias, security, compliance, explainability];

  // Only the Report Agent computes the final Trust Score
  const trustScore = calculateTrustScore(results);
  const grade = getTrustGrade(trustScore);

  const combinedReport = buildCombinedReport(results, trustScore, grade);

  return { results, trustScore, grade, combinedReport };
}

function buildCombinedReport(results: AgentResult[], trustScore: number, grade: string): string {
  let report = `## Final Trust Audit Report\n\n`;
  report += `**Trust Score: ${trustScore}/100** (Grade: ${grade})\n\n`;

  results.forEach(result => {
    report += `### ${result.agent} Agent\n`;
    report += `- **Score:** ${result.score}/100\n`;
    report += `- **Risk Level:** ${result.risk}\n`;
    if (result.findings.length > 0) {
      report += `- **Findings:**\n`;
      result.findings.forEach(f => {
        report += `  - ${f}\n`;
      });
    }
    if (result.recommendations.length > 0) {
      report += `- **Recommendations:**\n`;
      result.recommendations.forEach(r => {
        report += `  - ${r}\n`;
      });
    }
    report += `\n`;
  });

  report += `### Final Recommendations\n`;
  report += `- Address all High Risk findings before deployment.\n`;
  report += `- Re-run the full trust audit after remediation.\n`;
  report += `- Document governance changes for audit trails.\n`;

  return report;
}

// ============================================================================
// ORCHESTRATION HELPERS
// ============================================================================

// Run a SINGLE agent by type (multi-agent rule: single prompt → only that agent)
export function runSingleAgent(type: Exclude<AgentType, 'all'>, text: string, csvData?: string[][]): AgentResult {
  switch (type) {
    case 'privacy':
      return privacyAgent(text);
    case 'bias':
      return biasAgent(text, csvData);
    case 'security':
      return securityAgent(text);
    case 'compliance':
      return complianceAgent(text);
    case 'explainability': {
      // Explainability needs context — run all 4 analysis agents first, but only
      // surface the Explainability output (does NOT produce privacy/bias/etc scores).
      const ctx = [privacyAgent(text), biasAgent(text, csvData), securityAgent(text), complianceAgent(text)];
      return explainabilityAgent(ctx);
    }
    default:
      return privacyAgent(text);
  }
}

// Run ALL agents together (only when user asks for a full audit)
export function trustAudit(text: string, csvData?: string[][]): AgentResult[] {
  return reportAgent(text, csvData).results;
}

// Final Trust Score — computed ONLY by the Report Agent
export function calculateTrustScore(results: AgentResult[]): number {
  const weights: Record<string, number> = {
    privacy: 0.30,
    'bias detection': 0.20,
    security: 0.20,
    compliance: 0.15,
    explainability: 0.15,
  };

  const weightedSum = results.reduce((sum, result) => {
    const key = result.agent.toLowerCase();
    const weight = weights[key] ?? 0;
    return sum + result.score * weight;
  }, 0);

  return Math.round(weightedSum);
}

export function getTrustGrade(score: number): string {
  if (score >= 90) return 'A+';
  if (score >= 85) return 'A';
  if (score >= 80) return 'A-';
  if (score >= 75) return 'B+';
  if (score >= 70) return 'B';
  if (score >= 65) return 'B-';
  if (score >= 60) return 'C+';
  if (score >= 55) return 'C';
  if (score >= 50) return 'C-';
  if (score >= 40) return 'D';
  return 'F';
}
